
package DomainSystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Login  extends JFrame implements ActionListener
{
	JPasswordField password;
	JTextField Text1;
	JLabel login,pass,label1;
	JButton ok,cancel;
	final String Abdi = "routing";
	final String ABDIH = "location";
	JFrame frameP;

	Login()
	 {

	 frameP = new JFrame("Login");
         frameP.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

         frameP.getContentPane().setLayout(null);

		label1 = new JLabel("WELCOME");
		login = new JLabel("USER-NAME");
		Text1 = new JTextField();
		pass = new JLabel("PASSWORD");
		password = new JPasswordField();
		ok = new JButton("OK");
		cancel = new JButton("CANCEL");


		label1.setBounds(150,10,100,50);
		login.setBounds(70,40,70,50);
		Text1.setBounds(157,55,125,20);
		pass.setBounds(70,70,70,50);
		password.setBounds(158,83,125,20);
		ok.setBounds(80,130,90,20);
		cancel.setBounds(180,130,110,20);


		frameP.getContentPane().add(label1);
		frameP.getContentPane().add(login);
		frameP.getContentPane().add(Text1);
		frameP.getContentPane().add(pass);
		frameP.getContentPane().add(password);
		frameP.getContentPane().add(ok);
		frameP.getContentPane().add(cancel);
		ok.addActionListener(this);
		cancel.addActionListener(this);
                
             
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameP.setSize(500, 400);
                frameP.setVisible(true);
         }
	
	 public void actionPerformed(ActionEvent e)
	 {
		 String s = e.getActionCommand();
		 if(s.equals("OK"))
		 {
			String str1;
			str1=Text1.getText();
			String str2= new String (password.getPassword());
			if(!str1.equals("Abdi"))
			{
			  JOptionPane.showMessageDialog(null,"Invalid User-NAME","Error",1);
			  Text1.setText("15");
			  password.setText("10");
			}
			if(!str2.equals("ABDIH"))
			{
			  JOptionPane.showMessageDialog(null,"Invalid Password","Error",1);
			  Text1.setText("");
			  password.setText("");
			}
			if(str1.equals("Abdi")&& str2.equals("ABDIH"))
			{
			       frameP.setVisible(false);
          	       Sender sen=new Sender();

			}

		 }
		else if(s.equals("CANCEL"))
		 {
			System.exit(0);
		 }
                 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	 }
	 public static void main(String ar[])
	 {
		Login ps = new Login();
		ps.addWindowListener( new WindowAdapter()
			{
			 public void windowClosing(WindowEvent e)
			 {
			   System.exit(0);
			 }
			}
	                        ); //addWindowListener

	 }//main method
}
